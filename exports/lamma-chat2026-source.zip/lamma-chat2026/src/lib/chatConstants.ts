// Chat constants extracted from ChatScreen.tsx
// All data preserved exactly as-is. Pure refactor — no behavior change.

export const ROOMS_DEF = [
  { id: "egypt", name: "مصر", icon: "🇪🇬", count: 128, category: "social" },
  { id: "arab", name: "كل العرب", icon: "🌍", count: 99, category: "social" },
  { id: "youth", name: "لمة شباب وبنات", icon: "👫", count: 85, category: "social" },
  { id: "palestine", name: "فلسطين", icon: "🇵🇸", count: 54, category: "social" },
  { id: "fun", name: "فرفشة", icon: "🥳", count: 65, category: "fun" },
  { id: "games", name: "ألعاب", icon: "🎮", count: 41, category: "fun" },
  { id: "romance", name: "رومانسية", icon: "💖", count: 76, category: "relations" },
  { id: "admin", name: "الإدارة", icon: "🛡️", count: 3, category: "private" },
];

export const ROOM_CATEGORIES = [
  { id: "social", name: "اجتماعي", icon: "👥" },
  { id: "fun", name: "ترفيه", icon: "🎮" },
  { id: "relations", name: "علاقات", icon: "💖" },
  { id: "private", name: "خاصة", icon: "🛡️" },
];

export const GIFT_TYPES = [
  { icon: "🌹", name: "وردة", color: "#ef4444" },
  { icon: "💖", name: "قلب", color: "#f43f5e" },
  { icon: "☕", name: "قهوة", color: "#b45309" },
  { icon: "💎", name: "الماس", color: "#38bdf8" },
  { icon: "👑", name: "تاج", color: "#eab308" },
  { icon: "🏆", name: "كأس", color: "#f59e0b" },
  { icon: "🔥", name: "شعلة", color: "#f97316" },
];

export const EMOTICONS = [
  "😀","😃","😄","😁","😆","😅","😂","🤣","🥲","☺️","😊","😇","🙂","🙃","😉","😌","😍","🥰","😘","😗",
  "😙","😚","😋","😛","😝","😜","🤪","🤨","🧐","🤓","😎","🥸","🤩","🥳","😏","😒","😞","😔","😟","😕",
  "🙁","☹️","😣","😖","😫","😩","🥺","😢","😭","😤","😠","😡","🤬","🤯","😳","🥵","🥶","😱","😨","😰",
  "😥","😓","🤗","🤔","🤭","🤫","🤥","😶","😐","😑","😬","🙄","😯","😦","😧","😮","😲","🥱","😴","🤤",
  "😪","😵","🤐","🥴","🤢","🤮","🤧","😷","🤒","🤕","🤑","🤠","😈","👿","👹","👺","🤡","💩","👻","💀",
  "☠️","👽","👾","🤖","🎃","😺","😸","😹","😻","😼","😽","🙀","😿","😾","👋","🤚","🖐","✋","🖖","👌",
  "🤌","🤏","✌️","🤞","🤟","🤘","🤙","👈","👉","👆","🖕","👇","☝️","👍","👎","✊","👊","🤛","🤜","👏",
  "🙌","🤲","🤝","🙏","✍️","💅","🤳","💪","🦾","🦿","🦵","🦶","👂","🦻","👃","🧠","🫀","🫁","🦷","骨",
  "👀","👁","👅","👄","💋","🩸","❤️","🧡","💛","💚","💙","💜","🖤","🤍","🤎","💔","❣️","💕","💞","💓",
  "💗","💖","💘","💝",
];

export const SIMULATED_REPLIES = [
  "أهلاً وسهلاً بالجميع، نورتم غرفتنا الكبرى! 🌹",
  "يرجى الالتزام بالقواعد العامة واحترام الأعضاء 👍",
  "البث التوجيهي والمكالمات وتصميم الشات روعة بجد 😍",
  "هل جربتم تفعيل ميزة مميز VIP؟ تمنح دروع وتلوين فريد",
  "سرعة استجابة التطبيق خارقة!",
];
