import React, { useMemo, useState } from "react";
import { ChevronRight, Share2, Sparkles } from "lucide-react";
import LoginScreen from "./LoginScreen";

interface SimpleLoginScreenProps {
  onLogin: (
    username: string,
    role: string,
    color: string,
    uid?: string,
    email?: string,
    authProvider?: "supabase" | "guest",
  ) => void;
  primaryTheme: "dark" | "amoled";
  setPrimaryTheme: (theme: "dark" | "amoled") => void;
}

type WallTheme = "fire" | "ice" | "violet";

function generateRandomGuestId() {
  const num = Math.floor(Math.random() * 90000) + 10000;
  return `LC_Guest_${num}`;
}

const NICKNAME_COLORS = [
  "#22c55e",
  "#3fb950",
  "#58a6ff",
  "#a371f7",
  "#ef4444",
  "#f59e0b",
];

export default function SimpleLoginScreen({
  onLogin,
  primaryTheme,
  setPrimaryTheme,
}: SimpleLoginScreenProps) {
  const brandName = import.meta.env.VITE_BRAND_NAME || "Lamma Chat";
  const brandCredit = import.meta.env.VITE_BRAND_CREDIT || "MR mohamed samy";
  const loginHeroBg = import.meta.env.VITE_LOGIN_HERO_BG || "/images/login-hero.jpg";

  const [wallTheme, setWallTheme] = useState<WallTheme>(() => {
    const saved = localStorage.getItem("lamma_wall_theme");
    if (saved === "fire" || saved === "ice" || saved === "violet") return saved;
    return "fire";
  });

  const [showAdvanced, setShowAdvanced] = useState(false);
  const [showOptions, setShowOptions] = useState(false);
  const [copied, setCopied] = useState(false);

  const guestId = useMemo(() => generateRandomGuestId(), []);

  if (showAdvanced) {
    return (
      <LoginScreen
        onLogin={onLogin}
        primaryTheme={primaryTheme}
        setPrimaryTheme={setPrimaryTheme}
      />
    );
  }

  const setWallThemeSafe = (theme: WallTheme) => {
    setWallTheme(theme);
    localStorage.setItem("lamma_wall_theme", theme);
  };

  const handleEnter = () => {
    const assignedColor =
      NICKNAME_COLORS[Math.floor(Math.random() * NICKNAME_COLORS.length)];
    onLogin(guestId, "guest", assignedColor, undefined, undefined, "guest");
  };

  const handleCopyLink = async () => {
    const url = window.location.origin;
    try {
      await navigator.clipboard.writeText(url);
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    } catch {
      prompt("انسخ الرابط:", url);
    }
  };

  return (
    <div
      className="h-[100dvh] w-full relative overflow-hidden font-sans bg-transparent text-[color:var(--text-primary)]"
      dir="rtl"
      data-lamma-wall={wallTheme}
    >
      <div className="pointer-events-none absolute inset-0 overflow-hidden bg-black">
        <div
          className="absolute inset-0 bg-cover bg-center bg-no-repeat scale-110"
          style={{ backgroundImage: `url("${loginHeroBg}")` }}
        />
        <div className="absolute inset-0 bg-black/20" />
        <div className="absolute inset-0 bg-gradient-to-br from-black/45 via-black/28 to-[rgba(var(--lamma-wall-r),var(--lamma-wall-g),var(--lamma-wall-b),0.22)]" />
      </div>

      <div className="relative z-10 h-full w-full flex items-center justify-center px-4 py-10">
        <div className="w-full max-w-[560px] lamma-glass px-6 py-8 sm:px-10 sm:py-10 text-center">
          <img
            src="/images/am-logo.png"
            alt={brandName}
            onError={(e) => {
              const img = e.currentTarget;
              img.onerror = null;
              img.src = "/images/lamma-logo.png";
            }}
            className="mx-auto h-[220px] sm:h-[260px] w-auto object-contain"
            draggable={false}
          />

          <h1 className="mt-2 text-[56px] sm:text-[64px] font-black leading-none text-yellow-300">
            لمة
          </h1>

          <div className="mt-5 inline-flex items-center gap-3 rounded-2xl border border-yellow-400/25 bg-black/25 px-7 py-3 text-[13px] font-black text-yellow-200 backdrop-blur-xl">
            <span className="h-1.5 w-1.5 rounded-full bg-yellow-300/80" />
            <span>{brandCredit}</span>
            <span className="h-1.5 w-1.5 rounded-full bg-yellow-300/80" />
          </div>

          <button
            type="button"
            onClick={handleEnter}
            className="mt-6 mx-auto w-full max-w-[320px] rounded-2xl px-6 py-3 font-black text-[14px] text-emerald-200 bg-black/20 hover:bg-black/35 border border-white/10 backdrop-blur-xl transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <ChevronRight size={16} className="rotate-180 opacity-80" />
            <span>دوي هنا</span>
            <Sparkles size={16} className="opacity-90" />
          </button>

          <button
            type="button"
            onClick={() => setShowOptions(true)}
            className="mt-3 inline-flex items-center justify-center gap-2 px-4 py-2 rounded-full text-[11px] font-black text-gray-200 hover:text-white transition-all cursor-pointer bg-black/15 hover:bg-black/30 border border-white/10 backdrop-blur-xl"
          >
            <Share2 size={14} />
            <span>خيارات · مشاركة</span>
          </button>

          <div className="mt-6 flex items-center justify-center gap-2">
            <button
              type="button"
              onClick={() => setWallThemeSafe("fire")}
              className={`h-2.5 w-2.5 rounded-full transition-all cursor-pointer ${
                wallTheme === "fire"
                  ? "bg-amber-400 shadow-[0_0_0_3px_rgba(245,158,11,0.25)]"
                  : "bg-slate-400/60 hover:bg-slate-200/70"
              }`}
              aria-label="Fire"
            />
            <button
              type="button"
              onClick={() => setWallThemeSafe("ice")}
              className={`h-2.5 w-2.5 rounded-full transition-all cursor-pointer ${
                wallTheme === "ice"
                  ? "bg-sky-400 shadow-[0_0_0_3px_rgba(56,189,248,0.22)]"
                  : "bg-slate-400/60 hover:bg-slate-200/70"
              }`}
              aria-label="Ice"
            />
            <button
              type="button"
              onClick={() => setWallThemeSafe("violet")}
              className={`h-2.5 w-2.5 rounded-full transition-all cursor-pointer ${
                wallTheme === "violet"
                  ? "bg-violet-400 shadow-[0_0_0_3px_rgba(167,139,250,0.22)]"
                  : "bg-slate-400/60 hover:bg-slate-200/70"
              }`}
              aria-label="Violet"
            />
          </div>

          <div className="mt-6 text-[10px] text-gray-400 font-bold">
            © {new Date().getFullYear()} {brandName}
          </div>
        </div>
      </div>

      {showOptions && (
        <div
          className="fixed inset-0 z-[99998] flex items-center justify-center bg-black/80 p-4 backdrop-blur-md"
          onClick={() => setShowOptions(false)}
        >
          <div
            className="w-full max-w-md rounded-[28px] p-5 text-right lamma-modal-shell"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-4 mb-4 lamma-modal-header">
              <h3 className="text-base font-black text-white">خيارات · مشاركة</h3>
              <button
                onClick={() => setShowOptions(false)}
                className="rounded-full px-3 py-1.5 text-xs text-gray-400 transition-all cursor-pointer lamma-soft-action hover:text-white"
              >
                إغلاق
              </button>
            </div>

            <div className="space-y-3">
              <button
                type="button"
                onClick={handleCopyLink}
                className="w-full py-2.5 rounded-2xl font-black text-[12px] transition-all cursor-pointer text-white lamma-feature-primary flex items-center justify-center gap-2"
              >
                <Share2 size={14} />
                <span>{copied ? "تم النسخ" : "نسخ رابط الشات"}</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setShowOptions(false);
                  setShowAdvanced(true);
                }}
                className="w-full py-2.5 rounded-2xl font-black text-[12px] transition-all cursor-pointer text-gray-200 hover:text-white bg-black/20 hover:bg-black/35 border border-white/10 backdrop-blur-xl flex items-center justify-center gap-2"
              >
                <ChevronRight size={14} className="rotate-180 opacity-70" />
                <span>فتح شاشة الدخول الكاملة</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
